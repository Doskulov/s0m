Put the aim_map.bsp file in your maps folder (Steam\SteamApps\common\Counter-Strike Global Offensive\csgo\maps), and have fun :)

Map created by leplubodeslapin, special thanks to Freihh

- - - - - - - - - - - - - - - - - - - - - - - - - - - - -

www.VaKarM.net Des news qui font du bruit